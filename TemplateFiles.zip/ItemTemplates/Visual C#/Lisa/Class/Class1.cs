﻿using System;

namespace $rootnamespace$
{
    public class $safeitemname$
    {
    }
}